#! /usr/bin/env python3
import random,binascii 
print(random.random())
