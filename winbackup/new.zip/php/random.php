<?php

$a=random_int(0,100);
echo '<meta http-equiv="refresh" content="3">';
echo $a;
?>
