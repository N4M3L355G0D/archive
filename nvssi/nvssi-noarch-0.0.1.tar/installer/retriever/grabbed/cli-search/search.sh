#! /bin/bash

help="echo search.sh 'search term/phrase'"
browser=google-chrome-stable
site="https://www.google.com/search?q="
site1="https://www.google.com/webhp#q="
if [ "$1" == "--help" ] ; then
        $help
elif [ "$1" == "-h" ] ; then
        $help
elif [ "$1" == "-search" ] ; then
        $browser "$site$2"
elif [ "$1" == "-webhp" ] ; then
        $browser "$site$2"
fi
