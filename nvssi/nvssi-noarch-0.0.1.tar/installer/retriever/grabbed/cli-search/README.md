# cli-search
a command line search script
