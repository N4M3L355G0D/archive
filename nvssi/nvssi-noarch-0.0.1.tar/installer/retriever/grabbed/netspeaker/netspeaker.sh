#! /bin/bash


#DEFAULT settings go below this line
client=""
server=""
port=""
user=""
#DEFAULT settings go above this line

getopts ":s:c:p:u:" opt

if [ $opt == "s" ] ; then
	server=$OPTARG
	getopts ":c:p:u:" opt
		if [ $opt == "c" ] ; then
			client=$OPTARG
			getopts ":p:u:" opt
			if [ $opt == "p" ] ; then
				port=$OPTARG
				getopts ":u:"
				if [ $opt == "u" ] ; then
					user=$OPTARG
				fi
			elif [ $opt == "u" ] ; then 
				user=$OPTARG
				getopts ":p:" opt
				if [ $opt == "p" ] ; then
					port=$OPTARG
				fi
			fi
		elif [ $opt == "p" ] ; then
			port=$OPTARG
			getopts ":c:u:" opt
			if [ $opt == "c" ] ; then
				client=$OPTARG
				getopts ":u:" opt
				if [ $opt == "u" ] ; then
					user=$OPTARG
				fi
			elif [ $opt == "u" ] ; then
				user=$OPTARG
				getopts ":c:" opt
				if [ $opt == "c" ] ; then
					client=$OPTARG
				fi
			fi
		elif [ $opt === "u" ] ; then
			user=$OPTARG
			getopts ":c:p:" opt
			if [ $opt == "c" ] ; then
				client=$OPTARG
				getopts ":p:" opt
				if [ $opt == "p" ] ; then
					port=$OPTARG
				fi
			elif [ $opt == "p" ] ; then
				port=$OPTARG
				getopts ":c:" opt
				if [ $opt == "c" ] ; then
					client=$OPTARG
				fi
			fi
		fi
elif [ $opt == "c" ] ; then
	client=$OPTARG
	getopts ":s:p:u:" opt
		if [ $opt == "s" ] ; then
			server=$OPTARG
			getopts ":p:u:" opt
			if [ $opt == "p" ] ; then
				port=$OPTARG
				getopts ":u:" opt
				if [ $opt == "u" ] ; then
					user=$OPTARG
				fi
			elif [ $opt == "u" ] ; then
				user=$OPTARG
				getopts ":p:" opt
				if [ $opt == "p" ] ; then
					port=$OPTARG
					echo $port
				fi
			fi
		elif [ $opt == "p" ] ; then
			port=$OPTARG
			getopts ":s:u:" opt
			if [ $opt == "s" ] ; then
				server=$OPTARG
				getopts ":u:" opt
				if [ $opt == "u" ] ; then
					user=$OPTARG
				fi
			elif [ $opt == "u" ] ; then
				user=$OPTARG
				getopts ":s:" opt
				if [ $opt == "s" ] ; then
					server=$OPTARG
				fi
			fi
		elif [ $opt == "u" ] ; then
			user=$OPTARG
			getopts ":s:p:" opt
			if [ $opt == "s" ] ; then
				server=$OPTARG
				getopts ":p:" opt
				if [ $opt == "p" ] ; then
					port=$OPTARG
				fi
			elif [ $opt == "p" ] ; then
				port=$OPTARG
				getopts ":s:" opt
				if [ $opt == "s" ] ; then
					server=$OPTARG
				fi
			fi
		fi
elif [ $opt == "p" ] ; then
	port=$OPTARG
	getopts ":s:c:u:" opt
	if [ $opt == "s" ] ; then
			server=$OPTARG
			getopts ":c:u:" opt
			if [ $opt == "c" ] ; then
				client=$OPTARG
				getopts ":u:" opt
				if [ $opt == "u" ] ; then
					user=$OPTARG
				fi
			elif [ $opt == "u" ] ; then
				user=$OPTARG
				getopts ":c:" opt
				if [ $opt == "c" ] ; then
					client=$OPTARG
				fi
			fi
	elif [ $opt == "c" ] ; then
		client=$OPTARG
		getopts ":s:u:" opt
			if [ $opt == "s" ] ; then
				server=$OPTARG
				getopts ":u:" opt
				if [ $opt == "u" ] ; then
					user=$OPTARG
				fi
			elif [ $opt == "u" ] ; then
				user=$OPTARG
				getopts ":s:" opt
				if [ $opt == "s" ] ; then
					server=$OPTARG
				fi
			fi
	elif [ $opt == "u" ] ; then
		user=$OPTARG
		getopts ":c:s:" opt
			if [ $opt == "c" ] ; then
				client=$OPTARG
				getopts ":s:" opt
				if [ $opt == "s" ] ; then
					server=$OPTARG
				fi
			elif [ $opt == "s" ] ; then
				server=$OPTARG
				getopts ":c:" opt
				if [ $opt == "c" ] ; then
				client=$OPTARG
				fi
			fi
	fi
elif [ $opt == "u" ] ; then
	user=$OPTARG
	getopts ":s:c:p:" opt

	if [ $opt == "s" ] ; then
		server=$OPTARG
		getopts ":c:p:" opt
			if [ $opt == "c" ] ; then
				client=$OPTARG
				getopts ":p:" opt
				if [ $opt == "p" ] ; then
					port=$OPTARG
				fi
			elif [ $opt == "p" ] ; then
				port=$OPTARG
				getopts ":c:" opt
				if [ $opt == "c" ] ; then
					client=$OPTARG
				fi
			fi
	elif [ $opt == "c" ] ; then
		client=$OPTARG
		getopts ":s:p:" opt
			if [ $opt == "s" ] ; then
				server=$OPTARG
				getopts ":p:" opt
				if [ $opt == "p" ] ; then
					port=$OPTARG
				fi
			elif [ $opt == "p" ] ; then
				port=$OPTARG
				getopts ":s:" opt
				if [ $opt == "s" ] ; then
					server=$OPTARG
				fi
			fi
	elif [ $opt == "p" ] ; then
		port=$OPTARG
		getopts ":s:c:" opt
			if [ $opt == "s" ] ; then
				server=$OPTARG
				getopts ":c:" opt
				if [ $opt == "c" ] ; then
					client=$OPTARG
				fi
			elif [ $opt == "c" ] ; then
				client=$OPTARG
				getopts ":s:" opt
				if [ $opt == "s" ] ; then
					server=$OPTARG
				fi
			fi	
		
	fi
fi

echo "Server : $server"
echo "Client : $client"
echo "Port : $port"
echo "User : $user"
#sleep 30m

getopts ":av" opt

if [ -z $opt ] ; then
	echo "./netspeaker.sh <options> <mode>
	Please enter one of the following options provided below:
	MODE:
	-a		for streaming music to
			another machine being
			used as a speaker.

	-v		for streaming audio to
			another machine being 
			used as a speaker while
			video is being streamed 
			to the immediate machine.
	OPTIONS:
		-s	server address
		-c	client address
		-p	RTP port to use
		-u	SSH user to contact client
	WARNING:
		if you have not changed the
		default values, as specified 
		in the scripts topmost variables,
		then you must use the optional
		arguments for your desired results."
elif [ $opt == "a" ] ; then
  	ffmpeg -f alsa -i pulse -ac 2 -acodec libmp3lame -ar 48000 -ab 128k -f flv -f rtp rtp://$client:$port &> /dev/null &
	ssh -Y $user@$client ffplay rtp://$server:$port
elif [ $opt == "v" ] ; then
	ffmpeg -f alsa -i pulse -ac 2 -acodec libmp3lame -ar 48000 -ab 500k -f flv -f rtp rtp://$client:$port &>  /dev/null &
	ssh -Y $user@$client ffplay rtp://$server:$port
fi

back=`ps -a | grep -w ffmpeg | sed s/"    "/" "/g | cut -f5 -d" "`
if [ -z $back ] ; then
        exit
elif [ $back == "ffmpeg" ] ; then
        killall -15 ffmpeg
fi
