# simple-ohm

a command line tool for using ohms law.

to run, either:

python simple-ohm.py

        or
        
chmod +x simple-ohm.py
./simple-ohm.py <args....>

#Do Not remove the ohm, amp, or volt, .py files. These carry the necessary functions to operate Simple-ohm
Yours Truly,

NoGuiLinux
