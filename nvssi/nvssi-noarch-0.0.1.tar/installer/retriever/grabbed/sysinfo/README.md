# sysinfo
a general wrapper to ease the windows user into the Linux realm, and also makes life easier to have everything as a single tool.
