#! /bin/bash

ss=/opt/software/wps-office/et
wd=/opt/software/wps-office/wps
pd=/opt/software/wps-office/wpp
arch=`uname -m`
package64="http://kdl.cc.ksosoft.com/wps-community/download/a19/wps-office_9.1.0.4975~a19p1_x86_64.tar.xz"
pack64="wps-office_9.1.0.4975~a19p1_x86_64.tar.xz"
pack32="wps-office_9.1.0.4975~a19p1_x86.tar.xz"
dir64="wps-office_9.1.0.4975~a19p1_x86_64"
dir32="wps-office_9.1.0.4975~a19p1_x86"
package32="http://kdl.cc.ksosoft.com/wps-community/download/a19/wps-office_9.1.0.4975~a19p1_x86.tar.xz"
if [ -e $ss ] ; then
	if [ -e $wd ] ; then
		if [ -e $pd ] ; then
			getopts "wps" mode
			if [ $mode == "w" ] ; then
				echo "writer mode"
				/opt/software/wps-office/wps $@
			elif [ $mode == "p" ] ; then
				echo "presentation mode"
				/opt/software/wps-office/wpp $@
			elif [ $mode == "s" ] ; then
				echo "spread sheet mode"
				/opt/software/wps-office/et $@
			else
				echo "there is no such mode!"
				echo "syntax: "
				echo "wps-office.sh -w --- writer mode"
				echo "wps-office.sh -p --- presenation mode"
				echo "wps-office.sh -s --- spread sheet mode"
			fi

		fi
	fi
else
	echo "WPS Office is not installed to the /opt/software/wps-office Directory!"
	read -rp "Do you wish to go on ahead and install it to that directory? [Y/n]" install
	if [ $install == "n" ] ; then
		echo "okay, then, maybe I will see you later! "
		exit
	else
		if [ $arch == "x86_64" ] ; then
			wget -c "$package64"
			tar -xvf "$pack64"
			sudo mv "$dir64" wps-office && sudo mv wps-office /opt/software/
		elif [ $arch == "i686"] ; then
			wget -c "$package32"
			tar -xvf "$pack32"
			sudo mv "$dir32" wps-office && sudo mv wps-office /opt/software/
		else
			echo "That is not a valid architecture, or I am seeing an error of some kind. I do hope not, but it might happen."
		fi
	fi
fi

