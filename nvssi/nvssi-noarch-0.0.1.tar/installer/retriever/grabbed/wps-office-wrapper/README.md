# wps-office.sh
A bash wrapper for WPS Office, with the cabilityof grabbing and installing WPS office.
