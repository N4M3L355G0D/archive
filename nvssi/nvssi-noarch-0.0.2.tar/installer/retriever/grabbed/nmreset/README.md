# nmreset
A small script to automate the spoofing of a MAC address
