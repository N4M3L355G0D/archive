# netspeaker.sh
A Simple Bash Script to Automate audio transport over a network via RTP through FFMPEG

Defaults can be set within the Netspeaker.sh Bash Script

./netspeaker.sh <MODE> <options>

MODE

  --audio-only for audio streaming only
  
  --audio-video for audio streaming while playing video at the same time
  
  
options

  -c client address
  
  -s server address
  
  -p RTP port
  
  -u SSH user
  

Warning:

  1: you will need ffmpeg and openssh installed
  
  2: if you have not set the defaults within the script, you will need to use the options provided above
  
  3: both client and server should have pulseaudio, where alsa-plugin should pull from monitor of analog steroe
  
  4: both server and client should have openssh installed
  
