#! /bin/bash

rm "/opt/bin/$1"
